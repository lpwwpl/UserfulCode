#ifndef _SERVER_HEAD_H_
#define _SERVER_HEAD_H_

#include<stdio.h>

struct infor{
	char id[10];
	char name[20];
	char sex[4];
	char num[15];
	char date[15];
};
typedef struct infor infor_t;
#endif
